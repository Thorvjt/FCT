a=input("Enter your name: ")
print("Hello",a)