a=float(input("Enter the Celcious: "))
print("Degrees F:",a*1.8+32)