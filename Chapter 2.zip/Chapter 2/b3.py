a=input("Enter Hours: ")
b=input("Enter Rate: ")
print("Pay:",int(a)*float(b))